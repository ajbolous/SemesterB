#include<dos.h>
#include<bios.h>
#include<stdlib.h>
#include<time.h>

#define ECOLOR 4
#define PCOLOR 2
#define PACCOLOR 0xE
#define FCOLOR 5
#define BLACK 0
#define HCOLOR 1

#define ENEMYNUMBER 4
#define FOODNUMBER 10
#define POWERNUMBER 5

volatile int pacX = 100;
volatile int pacY = 100;
volatile int speed = 2;
volatile int score = 0;
volatile int timer = 0;
volatile int htimer =0;
int DIFF = 6;
volatile char direction = 0;
volatile int PowerUp = 0;

void interrupt (*save8) (void);
void interrupt (*save9)(void);

typedef struct food{
    int x;
    int y;
    int isAlive;
}Food;

typedef struct enemy{
    int x;
    int y;
    int isAlive;
}Enemy;

typedef struct power{
    int x;
    int y;
    int isAlive;
}Power;


 Enemy Enemies[ENEMYNUMBER];
 Food Foods[FOODNUMBER];
 Power Powers[POWERNUMBER];
 
void setVideoMode(char m)
{
   asm{
    push AX
    mov al,m
    mov ah,0
    int 10h
    pop AX
    }  
}
void setpixel(int x,int y,char color)
{
 asm{
    push AX
    push CX
    push DX
    
    mov ah,0ch
    mov al,color
    mov cx,word ptr x
    mov dx,word ptr y
    int 10h
    
    pop DX
    pop CX
    pop AX
    }     
}
void DrawEmptyBox(int xs,int ys,int width,int w,int h,char color)
{
   int i = 0,j=0;
   for(i =xs;i<xs+w;i++)
       for(j=ys;j<ys+h;j++)
        if((i>xs && i<xs+width) || (j>ys && j<ys+width) 
            || (i>xs+w-width && i<xs+w) || (j>ys+h-width && j<ys+h))
                setpixel(i,j,color);
}
            
void DrawEnemy(int xs,int ys,char color)
{
    setpixel(xs,ys,color);
    setpixel(xs-1,ys,color);
    setpixel(xs+1,ys,color);   
    setpixel(xs-1,ys-2,color);  
    setpixel(xs+1,ys-2,color);      
}
void DrawPac(int xs,int ys,char color)
{
    setpixel(xs-1,ys,color);  
    setpixel(xs,ys+1,color);  
    setpixel(xs+1,ys-1,color); 
    setpixel(xs,ys-1,color);
    setpixel(xs-1,ys-1,color);
    setpixel(xs-1,ys+1,color);
    setpixel(xs+1,ys+1,color);      
}
void DrawFood (int xs,int ys,int color)
{
     setpixel(xs-1,ys,color);  
    setpixel(xs+1,ys,color);  
    setpixel(xs,ys+1,color); 
    setpixel(xs,ys-1,color); 
}
void DrawPower(int xs,int ys,int color)
{
    setpixel(xs,ys,color);
    setpixel(xs-1,ys,color);  
    setpixel(xs-1,ys+1,color);  
    setpixel(xs,ys-1,color); 
}

void MoveEnemy(Enemy* e)
{
    int dir = rand()%4;
    DrawEnemy(e->x,e->y,BLACK);
    if(timer%8==0)
    {
    if(pacX-e->x>0) 
        dir = 0;
    else dir = 2;
    if(pacY-e->y>0)dir++;
    }
    switch(dir)
    {
        case 0 : if(e->x<190)e->x+=3;break;
        case 1 : if(e->y<190)e->y+=3;break;
        case 2 : if(e->y>60)e->y-=3;break;
        case 3 : if(e->x>60)e->x-=3;break;   
    }
   if(PowerUp)
       DrawEnemy(e->x,e->y,HCOLOR);
   else
        DrawEnemy(e->x,e->y,ECOLOR);
       
}

void endGame(int winner)
{
    if(winner)
            printf("\033[0m\033[3m\033[s\033[9;7fCongrats Winner SCORE : %d Points \033[0m \033[u",score);
    else
    printf("\033[5m\033[4m\033[s\033[9;7fGAME OVER SCORE : %d Points \033[0m \033[u",score);
    setvect(8,save8);
    setvect(9,save9);
    asm{
     mov ah,4ch
     int 21h    
    }
}

void DrawPacMan()
{
    DrawPac(pacX,pacY,BLACK);
    if(direction==0 && pacX<196)
        pacX+=speed;
    else if(direction==1 && pacY<196)
        pacY+=speed;
    else if(direction ==2 && pacX>54)
        pacX-=speed;
    else if(direction ==3 && pacY >54)
        pacY-=speed;
    DrawPac(pacX,pacY,PACCOLOR);
}
void CheckFood(Food* food)
{
  if(food->isAlive)
    if( (pacX-food->x<=3 && pacX-food->x>=-3) && (pacY-food->y<=3 && pacY-food->y>=-3) )
    {
     score++;
     DrawFood(food->x,food->y,BLACK);
     food->isAlive =0;
     if(score >= FOODNUMBER) endGame(1);
    }
    else
     DrawFood(food->x,food->y,FCOLOR);
    
}
void CheckPower(Power* p)
{
    if(p->isAlive)
        if( (pacX-p->x<=3 && pacX-p->x>=-3) && (pacY-p->y<=3 && pacY-p->y>=-3) )
        {
        DrawPower(p->x,p->y,BLACK);
        p->isAlive =0;
        PowerUp = 1;
        htimer  = 0;
        }
        else   DrawPower(p->x,p->y,PCOLOR);   
}
void CheckEnemy(Enemy* e)
{
    if(e->isAlive)
    if( (pacX-e->x<=3 && pacX-e->x>=-3) && (pacY-e->y<=3 && pacY-e->y>=-3) )
    {
     if(PowerUp)
     {
         DrawEnemy(e->x,e->y,BLACK);
         e->isAlive =0;
      }
     else endGame(0);
    }
}

void interrupt h9()
{
    char c = 0;
    asm{
     push ax
     pushf
     call dword ptr save9
     mov ah,1h
     int 16h
     jz releasekey
     mov ah,0h
     int 16h
     mov c,Ah
     pop ax
    }
   if(c ==0x48)
        direction = 3;
    else if(c==0x4b)
        direction = 2;
    else if (c==0x4d)
        direction = 0;
    else if(c==0x50)
        direction = 1;
 releasekey:asm{
     pop ax
     
 }
}
void interrupt h8()
{
    int i = 0;
    asm{
        pushf
        call dword ptr save8
    }
    timer++;
    if(PowerUp)
    {
     htimer++;
     printf("\033[5m\033[1m\033[s\033[6;6fScore: %d Points  POWERUP TIME!! %d\033[0m \033[u",score,(10-DIFF)-htimer/19);
    }else        
     printf("\033[5m\033[0m\033[s\033[6;6fScore: %d Points                    \033[0m \033[u",score);

 if(htimer>=(10-DIFF)*19)
 {
     PowerUp = 0;
     htimer  = 0;
 }

    DrawPacMan();
    if(timer%(19/DIFF)==0)
    {
        for(i=0;i<ENEMYNUMBER;i++)
            if(Enemies[i].isAlive)
              MoveEnemy(&Enemies[i]);
    }
    for(i=0;i<FOODNUMBER;i++)
        CheckFood(&Foods[i]);
    for(i=0;i<POWERNUMBER;i++)
               CheckPower(&Powers[i]);
    for(i=0;i<ENEMYNUMBER;i++)
        CheckEnemy(&Enemies[i]);
}

void initGame(int diff)
{
 int i  = 0;
 char c = 0;
 DIFF   = diff;
 
 srand(time(NULL));
    save8 = getvect(8);
    save9 = getvect(9);
    setVideoMode(0x13);
    DrawEmptyBox(50,50,2,150,150,9);

for(i=0;i<ENEMYNUMBER;i++)
{
   Enemies[i].x = rand()%120+60;
   Enemies[i].y = rand()%120+60;
   Enemies[i].isAlive = 1;
   MoveEnemy(&Enemies[i]);
}
for(i=0;i<FOODNUMBER;i++)
{
   Foods[i].x = rand()%120+60;
   Foods[i].y = rand()%120+60;
   Foods[i].isAlive = 1;
   DrawFood(Foods[i].x,Foods[i].y,FCOLOR);
}
for(i=0;i<POWERNUMBER;i++)
{
    Powers[i].x = rand()%120+60;
    Powers[i].y = rand()%120+60;
   Powers[i].isAlive = 1;
   DrawPower(Powers[i].x,Powers[i].y,PCOLOR);
}
    while(c!=13)
        c = getch();
    setvect(8,h8);
    setvect(9,h9);

}

void main()
{
    initGame(3);
    while(1){}
    return;
}
